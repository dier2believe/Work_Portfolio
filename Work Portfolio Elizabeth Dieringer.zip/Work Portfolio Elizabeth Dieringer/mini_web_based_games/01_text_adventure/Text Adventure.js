//MAP
var mapTitles = [];
mapTitles[0] = "<span class='titles'>The Golden Gate</span><br><br><span class='description'>You see the exit, a large golden gate, but when you try to push it open, it doesn't budge.  It's locked!</span>";
mapTitles[1] = "<span class='titles'>The Mystic Pond</span><br><br><span class='description'>You look out over the large pond.  It is so beautiful.</span>";
mapTitles[2] = "<span class='titles'>The Mortician's Shed</span><br><br><span class='description'>You walk in expecting something horrific, but are pleased to see that it is just a tool shed.</span>";
mapTitles[3] = "<span class='titles'>The Graveyard of the Undead</span><br><br><span class='description'>There is a lot of fog all around you, but you can just make out a freshly dug grave and a large shed.  You try to open the shed, but it is shut tight with a metal lock.</span>";
mapTitles[4] = "<span class='titles'>The Dark Basement</span><br><span class='description'><br>You can barely see anything the light is so dim, but there is a faint mold smell in the air.  You might want to get that inspected.  The only thing in the room is a small old safe that is locked with no key in sight.</span>";
mapTitles[5] = "<span style='font-size:15px, font-weight:bold'>START</span><span class='titles'> Home</span><br><br><span class='description'>You are just outside your outskirts cabin.  You see stairs to your left and the front door to your right.</span>";
mapTitles[6] = "<span class='titles'>Dirt Road</span><br><br><span class='description'>This road is what it is... a dirt road.  You see a backpack laying on the side of the road.</span>";
mapTitles[7] = "<span class='titles'>The Village Market Place</span><br><br><span class='description'>This place is so busy you can barely see all of the stands with people selling things from swords to cakes.  You see a stand in the distance that is selling... bolt cutters?</span>";
mapTitles[8] = "<span class='titles'>The Secret Vault</span><br><br><span class='description'>You look to see... an axe here?  Why would someone go through such precautions to keep an axe safe.</span>";
mapTitles[9] = "<span class='titles'>The Vast Woods</span><br><br><span class='description'>There are really tall trees all around you.  You look up and can't see the tops of any of them.  You can hear the trickling of water off to the east through the trees, but you can't get through them.</span>";
mapTitles[10] = "<span class='titles'>The Magical Fountain</span><br><br><span class='description'>You hear the flow of the water in the fountain and see a sign that says<br><em>Throw in a coin and make a wish!</em></span>";
mapTitles[11] = "<span class='titles'>The Stone Bridge</span><br><br><span class='description'>You can hear the running water that flows down the river beneath the bridge.  There is a dog at the end of the bridge that looks scared and won't come to you, but you see a gold key hanging around it's neck.</span>";
mapTitles[12] = "<span class='titles'>Secret Hallway</span><br><br><span class='description'>It seems to be a secret tunnel.  You look back at the wall and see the seemingly random shelf behind you.  There is a door at the end of the hallway that looks almost like a secret vault with a keypad next to it with 5 number spaces.</span>";
mapTitles[13] = "<span class='titles'>The Enormous Library</span><br><br><span class='description'>The library is too big to imagine but at the end of one of the rows there is a spot on one of the shelves that looks different.  It lookes like there is a missing space.</span>";
mapTitles[14] = "<span class='titles'>Castle Frontroom</span><br><br><span class='description'>You walk into the castle and see the magnificent entrance that leads to another room.</span>";
mapTitles[15] = "<span class='titles'>The Large Old Castle</span><br><br><span class='description'>You are amazed by the site of the old castle, but you can't get in because the door to get inside is locked.</span>";

//Map Paths
//North South East West
var mapPath = [];
mapPath[0] = [false, false, true, false];
mapPath[1] = [false, false, false, true];
mapPath[2] = [false, false, true, false];
mapPath[3] = [false, true, false, false];
mapPath[4] = [false, false, true, false];
mapPath[5] = [false, true, true, true];
mapPath[6] = [false, false, true, true];
mapPath[7] = [true, true, false, true];
mapPath[8] = [false, true, false, false];
mapPath[9] = [true, false, false, false];
mapPath[10] = [false, false, false, true];
mapPath[11] = [true, true, false, false];
mapPath[12] = [false, false, false, false];
mapPath[13] = [false, false, true, false];
mapPath[14] = [false, false, true, true];
mapPath[15] = [true, false, false, false];

//Blocked Path Messages
var blockedPathMessages = [];
blockedPathMessages[0] = "The only way out is through the gate.";
blockedPathMessages[1] = "You don't have a boat to go over the pond.";
blockedPathMessages[2] = "There is only one door on the shed.";
blockedPathMessages[3] = "You can't see that way because of the fog and don't want to go into the unknown";
blockedPathMessages[4] = "There is a brick wall in your way.";
blockedPathMessages[5] = "There is a large wall behind your house that you can not get over.";
blockedPathMessages[6] = "There are trees in your way.";
blockedPathMessages[7] = "There is a group of stands there.";
blockedPathMessages[8] = "There is a wall of steel in front of you.";
blockedPathMessages[9] = "There is a wall of trees in your way.";
blockedPathMessages[10] = "There is a wall with water running down it in front of you.";
blockedPathMessages[11] = "The bridge wall is in your way.";
blockedPathMessages[12] = "There is a wall there.";
blockedPathMessages[13] = "There is a shelf there.";
blockedPathMessages[14] = "There is a wall there.";
blockedPathMessages[15] = "The castle gate is in your way.";

//Task Blocked Path Messages
var taskBPM = [];
taskBPM[0] = "";
taskBPM[1] = "";
taskBPM[2] = "";
taskBPM[3] = "You try to open the door, but it is locked.";
taskBPM[4] = "";
taskBPM[5] = "";
taskBPM[6] = "";
taskBPM[7] = "";
taskBPM[8] = "";
taskBPM[9] = "You can barely see something behind the thick trees, but you can't get by the trees.";
taskBPM[10] = "";
taskBPM[11] = "";
taskBPM[12] = "";
taskBPM[13] = "";
taskBPM[14] = "";
taskBPM[15] = "The castle door is locked.";

//Images
var images = [];
images[0] = "00EndGate.jpg";
images[1] = "01Pond.png";
images[2] = "02Shed.jpg";
images[3] = "03Graveyard.jpg";
images[4] = "04Basement.jpg";
images[5] = "05Cottage.jpg";
images[6] = "06DirtRoad.jpg";
images[7] = "07Market.jpg";
images[8] = "08Vault.jpg";
images[9] = "09Woods.jpg";
images[10] = "10Fountain.jpeg";
images[11] = "11Bridge.jpg";
images[12] = "12SecretHallway.jpg";
images[13] = "13Library.jpg";
images[14] = "14CastleFrontroom.jpg";
images[15] = "15Castle.jpg";

//Backpack
var backpack = [];
var backpackDisplay = false;

var shed = false;
var grave = false;

//Location
var mapLocation = 5;

//player's input
var playersInput = "";

//GameMessage
var gameMessage = "";

//items
var itemsInRooms = ["old key", "zipcode", "backpack", "axe", "shovel"];
var itemLocations = [2, 5, 6, 8, 9];

var itemsIKnow = ["zipcode", "gold key", "eraser", "pencil", "paper", "book", "bolt cutters", "shovel", "$50 bill", "metal key", "bone", "axe", "coin", "old key", "doodle", "backpack"];
var item = "";

//actions
var actionsIKnow = [ "north", "south", "east", "west", "take", "drop", "use"];
var action = "";

//input and output
var output = document.querySelector("#output");
var input = document.querySelector("#input");
var image = document.querySelector("img");
var Screen = document.querySelector("#screen");
var winScreen = document.querySelector("#winScreen");

//Button
var playButton = document.querySelector("#playButton");
playButton.addEventListener("click", clickHandler, false);

var restart = document.querySelector("#restart");
restart.addEventListener("click", reset, false);

var randomReset = document.querySelector("#reset");
randomReset.addEventListener("click", reset, false);

var winExplore = document.querySelector("#explore");
winExplore.addEventListener("click", explore, false);

window.addEventListener("keydown", keydownHandler, false);

//Start Display
render();


//*******************************************************************
                    //FUNCTIONS
//*******************************************************************
function keydownHandler(event) {
    if(event.keyCode === 13) {
        playGame();
    }
}

function clickHandler() {
    playGame();
}

function playGame() {
    //Player's input
    playersInput = input.value;
    playersInput = playersInput.toLowerCase();
    
    //Reset variables
    gameMessage = "";
    action = "";
    
    //Player's action
    for(i = 0; i < actionsIKnow.length; i++) {
        if(playersInput.indexOf(actionsIKnow[i]) !== -1) {
            action = actionsIKnow[i];
            console.log("player's action: " + action);
            break;
        }
    }
    
    //With item
    for(i = 0; i < itemsIKnow.length; i++) {
        if(playersInput.indexOf(itemsIKnow[i]) !== -1) {
            item = itemsIKnow[i];
            console.log("player's item: " + item);
            break;
        }
    }
    
    //Choose action function
    switch(action) {
        case "north":
            if(mapPath[mapLocation][0]) {
                mapLocation -= 4;
            } else if(mapLocation === 12) {
                gameMessage = "The vault is shut tight you can't get it to open.";
            } else {
                gameMessage = blockedPathMessages[mapLocation];
            }
            break;
            
        case "south":
            if(mapPath[mapLocation][1]) {
                mapLocation += 4;
            } else {
                gameMessage = blockedPathMessages[mapLocation];
            }
            break;
            
        case "east":
            if(mapPath[mapLocation][2]) {
                mapLocation += 1;
            } else if(mapLocation === 9) {
                gameMessage = "You can't get by the trees, you need to get rid of the trees first.";
            } else if(mapLocation === 12){
                gameMessage = "The shelf is in your way.";
            } else{
                gameMessage = blockedPathMessages[mapLocation];
            }
            break;
            
        case "west":
            if(mapPath[mapLocation][3]) {
                mapLocation -= 1;
            } else if(mapLocation === 3) {
                gameMessage = "The shed is still locked tight.";
            } else if(mapLocation === 13) {
                gameMessage = "There is a shelf there.";
            } else if(mapLocation === 15) {
                gameMessage = "The castle door is locked.";
            } else {
                gameMessage = blockedPathMessages[mapLocation];
            }
            break;
            
        case "take":
            takeItem();
            break;
            
        case "drop":
            dropItem();
            break;
            
        case "use":
            useItem();
            break;
    }
    
    render();
}

function takeItem() {
    //Find the item
    var itemIndexNumber = itemsInRooms.indexOf(item);
    
    if(itemIndexNumber !== -1 && itemLocations[itemIndexNumber] === mapLocation) {
        if(item === "backpack") {
            backpackOutput.style.display = "block";
            backpackDisplay = true;
            itemsInRooms.splice(itemIndexNumber, 1);
            itemLocations.splice(itemIndexNumber, 1);
            itemsInRooms.push("book", "paper", "pencil", "eraser");
            itemLocations.push(6, 6, 6, 6);
            gameMessage = "You pick up the backpack, dump out the contents, and put it on your back."
            mapTitles[6] = "<span class='titles'>Dirt Road</span><br><br><span class='description'>This road is what it is a dirt road.</span>";
        } else {
            if(backpackDisplay) {
                if(backpack.length < 3) {
                    gameMessage = "You take the " + item + ".";
                    
                    //Move the stuff
                    backpack.push(item);
                    
                    itemsInRooms.splice(itemIndexNumber, 1);
                    itemLocations.splice(itemIndexNumber, 1);
                } else {
                    gameMessage = "Your backpack is full.";
                }
            } else {
                gameMessage = "You don't have anything to carry that in.";
            }
        }
    } else {
        gameMessage = "You can't do that.";
    }
}

function dropItem() {
    
    if(item === "backpack") {
        gameMessage = "You need to keep that.";
    } else {
        //Make sure that the backpack isn't empty
        if(backpack.length !== 0) {
            //Find item
            var backpackIndexNumber = backpack.indexOf(item);
            
            //If the item is in the backpack
            if(backpackIndexNumber !== -1) {
                gameMessage = "You drop the " + item + ".";
                
                //Move things around
                itemsInRooms.push(backpack[backpackIndexNumber]);
                itemLocations.push(mapLocation);
                
                backpack.splice(backpackIndexNumber, 1);
            } else {
                gameMessage = "You are not carrying that.";
            }
        } else {
            gameMessage = "You are not carrying anything.";
        }
    }
}

function useItem() {
    //Find item
    var backpackIndexNumber = backpack.indexOf(item);
    
    //is it there
    if(backpackIndexNumber === -1) {
        gameMessage += "Your backpack is empty.";
    } else {
        //is there stuff in the backpack
        if(backpack.length === 0) {
            gameMessage += "Your backpack is empty.";
        } else {
            //item there
            if(backpackIndexNumber !== -1) {
                switch(item) {
                    case "gold key":
                        if(mapLocation === 0) {
                            Screen.style.display = "none";
                            winScreen.style.display = "block";
                            restart.style.display = "inline-block";
                            explore.style.display = "inline-block";
                            /*backpack.splice(backpackIndexNumber, 1);
                            gameMessage = "You see the gate open and see a whole other town on the other side of the gate.  You win you found a way out.";
                            input.disabled = true;
                            mapTitles[0] = "";*/
                        } else {
                            gameMessage = "You look at how the key shines in the sun.";
                        }
                        break;
                        
                    case "zipcode":
                        if(mapLocation === 12) {
                            backpack.splice(backpackIndexNumber, 1);
                            gameMessage = "You put in the code and the vault door slowly turns and swings open.";
                            mapPath[12][0] = true;
                            mapTitles[12] = "<span class='titles'>Secret Hallway</span><br><br><span class='description'>It seems to be a secret tunnel.  You look back at the wall and see the seemingly random shelf behind you.  There is an open door at the end of the hallway.</span>";
                        } else {
                            gameMessage = "You look at the number and think of home.";
                        }
                        break;
                        
                    case "book":
                        if(mapLocation === 13) {
                            mapLocation = 12;
                            gameMessage = "You put the book into the slot and the wall turns around so that you are in a wierd tunnel.  You step out, take the book back, and the wall turns back around behind you.";
                        } else if(mapLocation === 12) {
                            mapLocation = 13;
                            gameMessage = "You put the book into the slot and the wall turns around so that you are back in the library.  You step out, take the book back, and the wall turns back around behind you.";
                        } else {
                            gameMessage = "You look through the book, but all of the pages are blank.";
                        }
                        break;
                        
                    case "shovel":
                        if(mapLocation === 3) {
                            backpack.splice(backpackIndexNumber, 1);
                            itemsInRooms.push("metal key");
                            itemLocations.push(mapLocation);
                            itemsInRooms.push("bone");
                            itemLocations.push(mapLocation);
                            gameMessage = "You dig up the grave and find a metal key and a bone.";
                        } else {
                            gameMessage = "You dig a hole in the dirt and then fill it back up.";
                        }
                        break;
                        
                    case "metal key":
                        if(mapLocation === 4) {
                            backpack.splice(backpackIndexNumber, 1);
                            itemsInRooms.push("$50 bill");
                            itemLocations.push(mapLocation);
                            itemsInRooms.push("coin");
                            itemLocations.push(mapLocation);
                            gameMessage = "You open the safe to find a $50 bill and a coin.";
                            mapTitles[4] = "<span class='titles'>The Dark Basement</span><br><span class='description'><br>You can barely see anything the light is so dim, but there is a faint mold smell in the air.  You might want to get that inspected.  The only thing in the room is a small old safe that is open.</span>";
                        } else {
                            gameMessage = "You look down at the shiny silver key";
                        }
                        break;
                        
                    case "$50 bill":
                        if(mapLocation === 7){
                            backpack.splice(backpackIndexNumber, 1);
                            backpack.push("bolt cutters");
                            gameMessage = "You give the merchant your $50 dollar bill and he hands you the bolt cutters which you put into your backpack.";
                        } else {
                            gameMessage = "You are $50 richer than you were.";
                        }
                        break;
                        
                    case "bolt cutters":
                        if(mapLocation === 3) {
                            backpack.splice(backpackIndexNumber, 1);
                            mapPath[3][3] = true;
                            gameMessage = "You use the bolt cutters to break the lock on the shed and open the doors.";
                            mapTitles[3] = "<span class='titles'>The Graveyard of the Undead</span><br><br><span class='description'>There is a lot of fog all around you, but you can just make out a freshly dug grave and a large shed.  The shed is hanging wide open.</span>";
                        } else {
                            gameMessage = "You could cut metal of some kind with those.";
                        }
                        break;
                        
                    case "bone":
                        if(mapLocation === 11) {
                            backpack.splice(backpackIndexNumber, 1);
                            backpack.push("gold key");
                            gameMessage = "You hold out the bone and the dog happily trots up to you.  You pet the dog and take the key from around it's neck.";
                            mapTitles[11] = "<span class='titles'>The Stone Bridge</span><br><br><span class='description'>You can hear the running water that flows down the river beneath the bridge.  The dog is sitting at the end of the bridge chewing away happily at it's bone.</span>";
                        } else {
                            gameMessage = "That doesn't look like a human bone... That looks more like a dog bone.";
                        }
                        break;
                        
                    case "old key":
                        if(mapLocation === 15) {
                            backpack.splice(backpackIndexNumber, 1);
                            mapPath[15][3] = true;
                            gameMessage = "You unlock the door with the key.";
                            mapTitles[15] = "<span class='titles'>The Large Old Castle</span><br><br><span class='description'>You are amazed by the site of the old castle with the now open and inviting door.</span>";
                        } else {
                            gameMessage = "The key is an old key... that's ironic.";
                        }
                        break;
                        
                    case "axe":
                        if(mapLocation === 9) {
                            backpack.splice(backpackIndexNumber, 1);
                            mapPath[9][2] = true;
                            gameMessage = "You cut down the trees in front of you and see a room of water behind them.";
                            mapTitles[9] = "<span class='titles'>The Vast Woods</span><br><br><span class='description'>There are really tall trees all around you.  You look up and can't see the tops of any of them.  You can hear the trickling of water off to the east and turn to see the room full of water.</span>";
                        } else {
                            gameMessage = "You practice swinging the axe.";
                        }
                        break;
                        
                    case "coin":
                        if(mapLocation === 10) {
                            mapLocation = 1;
                            gameMessage = "You throw the coin into the fountain and the next thing you know you are standing in front of a lake with the coin in your pocket.";
                        } else if(mapLocation === 1) {
                            mapLocation = 10;
                            gameMessage = "You through the coin into the lake and you look up to see the fountain.  You put your hand in your pocket to find the coin still there.";
                        } else {
                            gameMessage = "You fumble with the coin in your pocket.";
                        }
                        break;
                        
                    case "eraser":
                        if(backpack.indexOf("doodle") !== -1) {
                            gameMessage = "You erase your doodle from the page.";
                            backpack.splice(backpack.indexOf("doodle"), 1);
                            backpack.push("paper");
                        } else {
                            gameMessage = "You look down at the pink eraser in your hand. You don't have anything to erase.";
                        }
                        break;
                        
                    case "pencil":
                        if(backpack.indexOf("paper") !== -1) {
                            backpack.splice(backpack.indexOf("paper"), 1);
                            backpack.push("doodle");
                            gameMessage = "You sit down to rest and doodle on the paper with the pencil.";
                        } else {
                            gameMessage = "You need something to write on.";
                        }
                        break;
                        
                    case "paper":
                        gameMessage = "You look down at the blank page and imagine it as an origami frog... too bad you have no idea how to make that.";
                        break;
                        
                    case "doodle":
                        gameMessage = "You look at your doodle and are happy that you took those art classes.";
                        break;
                }
            }
        }
    }
}

function render() {
    //location
    output.innerHTML = mapTitles[mapLocation] + "<br>";
    image.src = "images/" + images[mapLocation];
    
    //item
    for(var i = 0; i < itemsInRooms.length; i++) {
        if(mapLocation === itemLocations[i]) {
            output.innerHTML += "<br><span id='backpackStyle'>You see a <strong>" + itemsInRooms[i] + "</strong> here.</span>";
        }
    }
    
    //game message
    output.innerHTML += "<br><span id='gameMessageStyle'>" + gameMessage + "</span>";
    
    //backpack
    
    if(backpack.length !== 0) {
        backpackOutput.innerHTML = "<br>You are carrying:<br>" + backpack.join("<br> ");
    } else {
        backpackOutput.innerHTML = "<br>You are not carrying anything";
    }
    
    input.value = "";
}

function explore() {
    winScreen.style.display = "none";
    Screen.style.display = "block";
    render();
}

function reset() {
    console.log("reset being called");
    //reset board
    winScreen.style.display = "none";
    Screen.style.display = "block";
    backpackDisplay = false;
    backpackOutput.style.display = "none";
    
    //MAP
    mapTitles[0] = "<span class='titles'>The Golden Gate</span><br><br><span class='description'>You see the exit, a large golden gate, but when you try to push it open, it doesn't budge.  It's locked!</span>";
    mapTitles[3] = "<span class='titles'>The Graveyard of the Undead</span><br><br><span class='description'>There is lots of fog all around you, but you can just make out a few gravestones and a large shed.  You try to open the shed, but it is shut tight with a metal lock.</span>";
    mapTitles[4] = "<span class='titles'>The Dark Basement</span><br><span class='description'><br>You can barely see anything the light is so dim, but there is a faint mold smell in the air.  You might want to get that inspected.  The only thing in the room is a small old safe that is locked with no key in sight.</span>";
    mapTitles[6] = "<span class='titles'>Dirt Road</span><br><br><span class='description'>This road is what it is... a dirt road.  You see a backpack laying on the side of the road.</span>";
    mapTitles[7] = "<span class='titles'>The Village Market Place</span><br><br><span class='description'>This place is so busy you can barely see all of the stands with people selling things from swords to cakes.  You see a stand in the distance that is selling... bolt cutters?</span>";
    mapTitles[9] = "<span class='titles'>The Vast Woods</span><br><br><span class='description'>There are really tall trees all around you.  You look up and can't see the tops of any of them.  You can hear the trickling of water off to the east through the trees, but you can't get through them.</span>";
    mapTitles[11] = "<span class='titles'>The Stone Bridge</span><br><br><span class='description'>You can hear the running water that flows down the river beneath the bridge.  There is a dog at the end of the bridge that looks scared and won't come to you, but you see a gold key hanging around it's neck.</span>";
    mapTitles[12] = "<span class='titles'>Secret Hallway</span><br><br><span class='description'>It seems to be a secret tunnel.  You look back at the wall and see the seemingly random shelf behind you.  There is a door at the end of the hallway that looks almost like a secret vault with a keypad next to it with 5 number spaces.</span>";
    mapTitles[15] = "<span class='titles'>The Large Old Castle</span><br><br><span class='description'>You are amazed by the site of the old castle, but you can't get in because the door inside is locked.</span>";
    
    //Map Paths
    //North South East West
    mapPath[3] = [false, true, false, false];
    mapPath[9] = [true, false, false, false];
    mapPath[12] = [false, false, false, false];
    mapPath[15] = [true, false, false, false];
    
    //Backpack
    backpack = [];
    //Location
    mapLocation = 5;

    //player's input
    playersInput = "";

    //GameMessage
    gameMessage = "";

    //items
    itemsInRooms = ["old key", "zipcode", "backpack", "axe", "shovel"];
    itemLocations = [2, 5, 6, 8, 9];
    item = "";
    
    //action
    action = "";
    
    render();
}