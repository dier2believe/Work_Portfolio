document.querySelector("#firstPage").addEventListener("click", firstPage, false);
function firstPage() {
    mainReset();
    window.location = "question.html";
}

window.onload = initGame;

var roll = document.querySelector("#roll");
roll.addEventListener("click", rollDice, false);

var hiddenDice = [];
hiddenDice[0] = document.querySelector("#noDie1");
hiddenDice[1] = document.querySelector("#noDie2");
hiddenDice[2] = document.querySelector("#noDie3");
hiddenDice[3] = document.querySelector("#noDie4");
hiddenDice[4] = document.querySelector("#noDie5");
hiddenDice[5] = document.querySelector("#noDie6");


//Divs to display the dice
var disDie1 = document.querySelector("#die1");
var disDie2 = document.querySelector("#die2");
var disDie3 = document.querySelector("#die3");
var disDie4 = document.querySelector("#die4");
var disDie5 = document.querySelector("#die5");

var disDice = [disDie1, disDie2, disDie3, disDie4, disDie5];

//Freezing the displayed dice
disDie1.addEventListener("click", freezeDie.bind(this, 0), false);
disDie2.addEventListener("click", freezeDie.bind(this, 1), false);
disDie3.addEventListener("click", freezeDie.bind(this, 2), false);
disDie4.addEventListener("click", freezeDie.bind(this, 3), false);
disDie5.addEventListener("click", freezeDie.bind(this, 4), false);

//Score buttons
document.querySelector("#scoreButton0").addEventListener("click", scoreClicked.bind(this, 1), false);
document.querySelector("#scoreButton1").addEventListener("click", scoreClicked.bind(this, 2), false);
document.querySelector("#scoreButton2").addEventListener("click", scoreClicked.bind(this, 3), false);
document.querySelector("#scoreButton3").addEventListener("click", scoreClicked.bind(this, 4), false);
document.querySelector("#scoreButton4").addEventListener("click", scoreClicked.bind(this, 5), false);
document.querySelector("#scoreButton5").addEventListener("click", scoreClicked.bind(this, 6), false);
document.querySelector("#scoreButton9").addEventListener("click", scoreClicked.bind(this, "threeKind"), false);
document.querySelector("#scoreButton10").addEventListener("click", scoreClicked.bind(this, "fourKind"), false);
document.querySelector("#scoreButton11").addEventListener("click", scoreClicked.bind(this, "fullHouse"), false);
document.querySelector("#scoreButton12").addEventListener("click", scoreClicked.bind(this, "smStraight"), false);
document.querySelector("#scoreButton13").addEventListener("click", scoreClicked.bind(this, "lgStraight"), false);
document.querySelector("#scoreButton14").addEventListener("click", scoreClicked.bind(this, "yahtzee"), false);
document.querySelector("#scoreButton15").addEventListener("click", scoreClicked.bind(this, "chance"), false);

//Game Over screen connection
var gameOverScreen = document.querySelector("#gameOverScreen");
/*var restartButton = document.querySelector("#restartButton");
restartButton.addEventListener("click", resetGame, false);*/
var output = document.querySelector("#output");
var gameMessage = "";

//Variables for checking if they have rolled 3 times
//so that you don't keep rolling
var rollNum = 0;
var canRoll = true;
var turnCount = 0;
var gameOver = false;

var upperSum = 0;
var lowerSum = 0;

die1Freeze = document.querySelector("#die1Freeze");
die2Freeze = document.querySelector("#die2Freeze");
die3Freeze = document.querySelector("#die3Freeze");
die4Freeze = document.querySelector("#die4Freeze");
die5Freeze = document.querySelector("#die5Freeze");

var diceFreeze = [die1Freeze, die2Freeze, die3Freeze, die4Freeze, die5Freeze];

//   OBJECTS

var dieObj = {
    freeze: false,
    num: 1
}

//Object for each die
var die1 = Object.create(dieObj);
var die2 = Object.create(dieObj);
var die3 = Object.create(dieObj);
var die4 = Object.create(dieObj);
var die5 = Object.create(dieObj);

var dice = [die1, die2, die3, die4, die5];


var scoreCard = {
    1: false,
    2: false,
    3: false,
    4: false,
    5: false,
    6: false,
    
    threeKind: false,
    fourKind: false,
    fullHouse: false,
    smStraight: false,
    lgStraight: false,
    yahtzee: false,
    chance: false
};

function initGame() {
	roll.disabled = false;
	beforeHighScore();
    document.querySelector("#highScoreDiv").innerHTML = "High Score:<br>" + findCookieValue("highScore=");
    
    console.log("ready to start");
    /*document.querySelector("#highScoreDiv").innerHTML = "High Score:<br>" + localStorage.getItem("highScore");
    if(document.querySelector("#highScoreDiv").innerHTML === "High Score:<br>") {
        document.querySelector("#highScoreDiv").innerHTML = "High Score:<br>0";
    }*/
}

//Rolling the dice
function rollDice() {
    if(gameOver === true) { mainReset(); }
    if(canRoll === true) {
        //Runs through all of the dice and randomizes their number
        for(var i = 0; i < dice.length; i++) {
            var die = dice[i];
            //checks to see if the die is frozen or if the game is over
            if(die.freeze === false && canRoll === true) {
                var ranNum = randomNum(1, 6);
                die.num = ranNum;
            }
        }
        //adds up the rolls
        rollNum++;
    }
    
    checkScore();
    
    render();
    
    if(rollNum === 3) {
        render();
        /*for(var j = 0; j < dice.length; j++) {
            dice[j].freeze = false;
        }*/
    }
}

function freezeDie(zdieNum) {
    //  Freezes or unfreezes dice
    if(rollNum > 0 && canRoll === true) {
        var dieNum = dice[zdieNum];
        //toggle the dice freezing
        dieNum.freeze = !dieNum.freeze;
    }
    
    render();
}


function checkScore() {
    //console.log("CHECK SCORE CALLED");
    var diceNums = [];
    
    //figures out what numbers there are and puts them into an array
    for(var num = 0; num < dice.length; num++) {
        theDie = dice[num];
        diceNums.push(theDie.num);
    }
    
    //puts the numbers in order and displays them
    diceNums.sort();
    gameMessage = diceNums.join(" - ");
    
    var multiNums = [];
    var multiSameNums = [];
    
    var yahtzee = false;
    //Checks all the dice and sees if there are any pairs
    for(var tNum = 0; tNum < diceNums.length; tNum++) {
        var numOfSame = 0;
        var tDie = diceNums[tNum];
        //console.log("tDie " + tDie);
        
        for(var h = 0; h < diceNums.length; h++) {
            //console.log("diceNums[h] " + diceNums[h]);
            if(tDie === diceNums[h]) {
                numOfSame++;
            }
        }
        
        //checks to see if all of the numbers are the same (Yahtzee)
        if(numOfSame == 5 && multiNums.indexOf(tDie) === -1) {
            gameMessage += "<br>You have a YAHTZEE!";
            var yahtzee = true;
        }
        
        // checks to see if there are 2 or more of a number
        if(numOfSame >= 2 && multiNums.indexOf(tDie) === -1 && scoreCard[tDie] === false) {
            gameMessage += "<br>You have " + (numOfSame) + " " + tDie + "s.";
            multiNums.push(tDie);
        }
        if(scoreCard[tDie] === false) {
            if((tDie * numOfSame) != 0) {
                document.querySelector("#scoreDiv" + (tDie - 1)).innerHTML = tDie * numOfSame;
            } else {
                document.querySelector("#scoreDiv" + (tDie - 1)).innerHTML = "";
            }
        }
        
        //puts all the dice numbers and the number of the same die
        multiSameNums.push([theDie, numOfSame]);
        numOfSame = 0;
    }
    
    if(yahtzee === true && scoreCard.yahtzee === false) {
        document.querySelector("#scoreDiv14").innerHTML = 50;
    }
    
    //checks to see if there is a double and/or a triple
    var double = false;
    var triple = false;
    var diceNumsSum = 0;
    for(var w = 0; w < diceNums.length; w++) {
        diceNumsSum += diceNums[w];
    }
    for(var sNum = 0; sNum < multiSameNums.length; sNum++) {
        if(multiSameNums[sNum][1] === 2) {
            double = true;
        } else if(multiSameNums[sNum][1] === 3) {
            triple = true;
        }
        
        if(multiSameNums[sNum][1] >= 3 && scoreCard.threeKind === false) {
            document.querySelector("#scoreDiv9").innerHTML = diceNumsSum;
        }
        if(multiSameNums[sNum][1] >= 4 && scoreCard.fourKind === false) {
            document.querySelector("#scoreDiv10").innerHTML = diceNumsSum;
        }
    }
    
    //if there is a double and a triple then it is a full house
    if(double === true && triple === true) {
        gameMessage += "<br>You have a full house!";
        document.querySelector("#scoreDiv11").innerHTML = 25;
    }
    
    //Checks all the dice and sees if there are any straights.
    //console.log(diceNums[0]);
    var nextNum = diceNums[0] + 1;
    var straightNums = 0;
    for(var oNum = 0; oNum < diceNums.length; oNum++) {
        //console.log("die num " + diceNums[oNum]);
        //console.log("nextNum " + nextNum);
        if(diceNums[oNum] === (nextNum - 1)) {
            nextNum++;
            straightNums++;
        }
    }
    var nextNum = diceNums[1] + 1;
    var straightNums2 = 0;
    for(var oNum = 0; oNum < diceNums.length; oNum++) {
        //console.log("die num " + diceNums[oNum]);
        //console.log("nextNum " + nextNum);
        if(diceNums[oNum] === (nextNum - 1)) {
            nextNum++;
            straightNums2++;
        }
    }
    //console.log(straightNums);
    if(straightNums === 5) {
        gameMessage += "<br>You have a large straight!";
        document.querySelector("#scoreDiv13").innerHTML = 40;
    }
    if(straightNums >= 4 || straightNums2 >= 4) {
        gameMessage += "<br>You have a small straight!";
        document.querySelector("#scoreDiv12").innerHTML = 30;
    }
    
    if(scoreCard.chance === false) {
        var sum = 0;
        for(var p = 0; p < diceNums.length; p++) {
            sum += diceNums[p];
        }
        document.querySelector("#scoreDiv15").innerHTML = sum;
    }
    
}


function render() {
    //runs through each one of the dice
    for(var i = 0; i < dice.length; i++) {
        var die = dice[i];
        disDie = disDice[i];
        //switches the image to the random number
        disDie.src = hiddenDice[die.num - 1].src;
        if(die.freeze === true) {
            var frozenDie = diceFreeze[i];
            frozenDie.style.opacity = "1";
        } else {
            var frozenDie = diceFreeze[i];
            frozenDie.style.opacity = "0";
        }
    }
    
    if(rollNum === 3) {
        gameOverScreen.style.opacity = "1";
        canRoll = false;
        rollNum++;
        
        checkScore();
    }
    
    output.innerHTML = gameMessage;
}

function scoreClicked(zSection) {
    if(rollNum > 0) {
    switch(zSection) {
        case 1:
            document.querySelector("#scoreButton0").style.visibility = "hidden";
            document.querySelector("#scoreDiv0").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv0").innerHTML === "") { document.querySelector("#scoreDiv0").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case 2:
            document.querySelector("#scoreButton1").style.visibility = "hidden";
            document.querySelector("#scoreDiv1").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv1").innerHTML === "") { document.querySelector("#scoreDiv1").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case 3:
            document.querySelector("#scoreButton2").style.visibility = "hidden";
            document.querySelector("#scoreDiv2").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv2").innerHTML === "") { document.querySelector("#scoreDiv2").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case 4:
            document.querySelector("#scoreButton3").style.visibility = "hidden";
            document.querySelector("#scoreDiv3").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv3").innerHTML === "") { document.querySelector("#scoreDiv3").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case 5:
            document.querySelector("#scoreButton4").style.visibility = "hidden";
            document.querySelector("#scoreDiv4").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv4").innerHTML === "") { document.querySelector("#scoreDiv4").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case 6:
            document.querySelector("#scoreButton5").style.visibility = "hidden";
            document.querySelector("#scoreDiv5").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv5").innerHTML === "") { document.querySelector("#scoreDiv5").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
            
        case "threeKind":
            document.querySelector("#scoreButton9").style.visibility = "hidden";
            document.querySelector("#scoreDiv9").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv9").innerHTML === "") { document.querySelector("#scoreDiv9").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case "fourKind":
            document.querySelector("#scoreButton10").style.visibility = "hidden";
            document.querySelector("#scoreDiv10").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv10").innerHTML === "") { document.querySelector("#scoreDiv10").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case "fullHouse":
            document.querySelector("#scoreButton11").style.visibility = "hidden";
            document.querySelector("#scoreDiv11").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv11").innerHTML === "") { document.querySelector("#scoreDiv11").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case "smStraight":
            document.querySelector("#scoreButton12").style.visibility = "hidden";
            document.querySelector("#scoreDiv12").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv12").innerHTML === "") { document.querySelector("#scoreDiv12").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case "lgStraight":
            document.querySelector("#scoreButton13").style.visibility = "hidden";
            document.querySelector("#scoreDiv13").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv13").innerHTML === "") { document.querySelector("#scoreDiv13").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case "yahtzee":
            document.querySelector("#scoreButton14").style.visibility = "hidden";
            document.querySelector("#scoreDiv14").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv14").innerHTML === "") { document.querySelector("#scoreDiv14").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
        case "chance":
            document.querySelector("#scoreButton15").style.visibility = "hidden";
            document.querySelector("#scoreDiv15").style.fontSize = "15px";
            if(document.querySelector("#scoreDiv15").innerHTML === "") { document.querySelector("#scoreDiv15").innerHTML = 0; }
            scoreCard[zSection] = true;
            break;
    }
    
    turnCount++
    
    resetGame();
    calcFinalScore();
    
    if(turnCount >= 13) {
        gameOver = true;
        calcHighScore();
    }
    }
}

function resetGame() {
    
    for(var a = 1; a < 7; a++) {
        if(scoreCard[a] === false) {
            document.querySelector("#scoreDiv" + (a - 1)).innerHTML = "";
        }
    }
    if(scoreCard.threeKind === false) {
        document.querySelector("#scoreDiv9").innerHTML = "";
    }
    if(scoreCard.fourKind === false) {
        document.querySelector("#scoreDiv10").innerHTML = "";
    }
    if(scoreCard.fullHouse === false) {
        document.querySelector("#scoreDiv11").innerHTML = "";
    }
    if(scoreCard.smStraight === false) {
        document.querySelector("#scoreDiv12").innerHTML = "";
    }
    if(scoreCard.lgStraight === false) {
        document.querySelector("#scoreDiv13").innerHTML = "";
    }
    if(scoreCard.yahtzee === false) {
        document.querySelector("#scoreDiv14").innerHTML = "";
    }
    if(scoreCard.chance === false) {
        document.querySelector("#scoreDiv15").innerHTML = "";
    }
    
    gameOverScreen.style.opacity = "0";
    for(var i = 0; i < dice.length; i++) {
        die = dice[i];
        die.freeze = false;
        die.num = 1;
    }
    
    rollNum = 0;
    gameMessage = "";
    
    canRoll = true;
    
    render();
}

function mainReset() {
    resetGame();
    
    for(var i = 0; i <= 18; i++) {
        if(i != 6 && i != 7 && i != 8 && i != 16 && i != 17 && i != 18) {
            document.querySelector("#scoreDiv" + i).innerHTML = "";
            document.querySelector("#scoreButton" + i).style.visibility = "visible";
    		document.querySelector("#scoreDiv" + i).style.fontSize = "8px";
        } else if(i === 6 || i === 7 || i === 8 || i === 17 || i === 18) {
            document.querySelector("#scoreDiv" + i).innerHTML = "";
        }
    }
    for(var j = 1; j <= 6; j++) {
    	scoreCard[j] = false;
    }
    
    scoreCard.threeKind = false;
    scoreCard.fourKind = false;
    scoreCard.fullHouse = false;
    scoreCard.smStraight = false;
    scoreCard.lgStraight = false;
    scoreCard.yahtzee = false;
    scoreCard.chance = false;
    
    player = 1;
    turnCount = 0;
    rollNum = 0;
    gameOver = false;
}

function calcFinalScore() {
    // first half of the Score card
    upperSum = 0;
    for(var i = 0; i <= 5; i++) {
        if(document.querySelector("#scoreDiv" + i).innerHTML != "") {
            upperSum += Number(document.querySelector("#scoreDiv" + i).innerHTML);
        }
    }
    document.querySelector("#scoreDiv6").innerHTML = upperSum;
    
    if(upperSum >= 63) {
        document.querySelector("#scoreDiv7").innerHTML = 35;
    } else {
        document.querySelector("#scoreDiv7").innerHTML = 0;
    }
    
    document.querySelector("#scoreDiv8").innerHTML = upperSum + Number(document.querySelector("#scoreDiv7").innerHTML);
    
    // second half of the Score card
    lowerSum = 0;
    for(var j = 9; j <= 15; j++) {
        if(document.querySelector("#scoreDiv" + j).innerHTML != "") {
            lowerSum += Number(document.querySelector("#scoreDiv" + j).innerHTML);
        }
    }
    document.querySelector("#scoreDiv17").innerHTML = lowerSum;
    
    document.querySelector("#scoreDiv18").innerHTML = upperSum + lowerSum;
}

function beforeHighScore() {
    console.log("beforeHighScore called");
    
    
    
    //var tempHighScoreNum = findCookieValue("highScore=");
    
    /*if( isNaN(tempHighScoreNum) === true ) {
        document.cookie = "highScore=" + 0;
    }*/
}

function calcHighScore() {
    console.log("calcHighScore called");
    
    var scoreNum = Number(document.querySelector("#scoreDiv18").innerHTML);
    var highScoreNum = findCookieValue("highScore=");
    
    if(scoreNum > Number(highScoreNum)) {
        document.cookie = "highScore=" + scoreNum;
        document.querySelector("#highScoreDiv").innerHTML = "High Score:<br>" + scoreNum;
    }
}

function findCookieValue(zName) {
    var theCookie = document.cookie;
    var tempCookie = theCookie.substr(zName.length, 3);
    var semiC = tempCookie.indexOf(";");
    return tempCookie.substr(0, semiC);
}


function randomNum(Min, Max) {
    return Math.floor(Math.random() * (Max - Min + 1) + Min);
}