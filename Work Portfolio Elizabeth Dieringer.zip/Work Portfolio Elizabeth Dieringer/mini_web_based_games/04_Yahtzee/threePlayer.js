document.querySelector("#firstPage").addEventListener("click", firstPage, false);
function firstPage() {
    mainReset();
    window.location = "question.html";
}

document.querySelector("#roll").disabled = true;
window.onload = initGame;
function initGame() {
    document.querySelector("#roll").disabled = false;
}

var player = 1;

var roll = document.querySelector("#roll");
roll.addEventListener("click", rollDice, false);

var hiddenDice = [];
hiddenDice[0] = document.querySelector("#noDie1");
hiddenDice[1] = document.querySelector("#noDie2");
hiddenDice[2] = document.querySelector("#noDie3");
hiddenDice[3] = document.querySelector("#noDie4");
hiddenDice[4] = document.querySelector("#noDie5");
hiddenDice[5] = document.querySelector("#noDie6");


//Divs to display the dice
var disDie1 = document.querySelector("#die1");
var disDie2 = document.querySelector("#die2");
var disDie3 = document.querySelector("#die3");
var disDie4 = document.querySelector("#die4");
var disDie5 = document.querySelector("#die5");

var disDice = [disDie1, disDie2, disDie3, disDie4, disDie5];

//Freezing the displayed dice
disDie1.addEventListener("click", freezeDie.bind(this, 0), false);
disDie2.addEventListener("click", freezeDie.bind(this, 1), false);
disDie3.addEventListener("click", freezeDie.bind(this, 2), false);
disDie4.addEventListener("click", freezeDie.bind(this, 3), false);
disDie5.addEventListener("click", freezeDie.bind(this, 4), false);

//Score buttons
document.querySelector("#scoreButton0").addEventListener("click", scoreClicked.bind(this, 1, 1), false);
document.querySelector("#scoreButton1").addEventListener("click", scoreClicked.bind(this, 2, 1), false);
document.querySelector("#scoreButton2").addEventListener("click", scoreClicked.bind(this, 3, 1), false);
document.querySelector("#scoreButton3").addEventListener("click", scoreClicked.bind(this, 4, 1), false);
document.querySelector("#scoreButton4").addEventListener("click", scoreClicked.bind(this, 5, 1), false);
document.querySelector("#scoreButton5").addEventListener("click", scoreClicked.bind(this, 6, 1), false);
document.querySelector("#scoreButton9").addEventListener("click", scoreClicked.bind(this, "threeKind", 1), false);
document.querySelector("#scoreButton10").addEventListener("click", scoreClicked.bind(this, "fourKind", 1), false);
document.querySelector("#scoreButton11").addEventListener("click", scoreClicked.bind(this, "fullHouse", 1), false);
document.querySelector("#scoreButton12").addEventListener("click", scoreClicked.bind(this, "smStraight", 1), false);
document.querySelector("#scoreButton13").addEventListener("click", scoreClicked.bind(this, "lgStraight", 1), false);
document.querySelector("#scoreButton14").addEventListener("click", scoreClicked.bind(this, "yahtzee", 1), false);
document.querySelector("#scoreButton15").addEventListener("click", scoreClicked.bind(this, "chance", 1), false);

document.querySelector("#score2Button0").addEventListener("click", scoreClicked.bind(this, 1, 2), false);
document.querySelector("#score2Button1").addEventListener("click", scoreClicked.bind(this, 2, 2), false);
document.querySelector("#score2Button2").addEventListener("click", scoreClicked.bind(this, 3, 2), false);
document.querySelector("#score2Button3").addEventListener("click", scoreClicked.bind(this, 4, 2), false);
document.querySelector("#score2Button4").addEventListener("click", scoreClicked.bind(this, 5, 2), false);
document.querySelector("#score2Button5").addEventListener("click", scoreClicked.bind(this, 6, 2), false);
document.querySelector("#score2Button9").addEventListener("click", scoreClicked.bind(this, "threeKind", 2), false);
document.querySelector("#score2Button10").addEventListener("click", scoreClicked.bind(this, "fourKind", 2), false);
document.querySelector("#score2Button11").addEventListener("click", scoreClicked.bind(this, "fullHouse", 2), false);
document.querySelector("#score2Button12").addEventListener("click", scoreClicked.bind(this, "smStraight", 2), false);
document.querySelector("#score2Button13").addEventListener("click", scoreClicked.bind(this, "lgStraight", 2), false);
document.querySelector("#score2Button14").addEventListener("click", scoreClicked.bind(this, "yahtzee", 2), false);
document.querySelector("#score2Button15").addEventListener("click", scoreClicked.bind(this, "chance", 2), false);

document.querySelector("#score3Button0").addEventListener("click", scoreClicked.bind(this, 1, 3), false);
document.querySelector("#score3Button1").addEventListener("click", scoreClicked.bind(this, 2, 3), false);
document.querySelector("#score3Button2").addEventListener("click", scoreClicked.bind(this, 3, 3), false);
document.querySelector("#score3Button3").addEventListener("click", scoreClicked.bind(this, 4, 3), false);
document.querySelector("#score3Button4").addEventListener("click", scoreClicked.bind(this, 5, 3), false);
document.querySelector("#score3Button5").addEventListener("click", scoreClicked.bind(this, 6, 3), false);
document.querySelector("#score3Button9").addEventListener("click", scoreClicked.bind(this, "threeKind", 3), false);
document.querySelector("#score3Button10").addEventListener("click", scoreClicked.bind(this, "fourKind", 3), false);
document.querySelector("#score3Button11").addEventListener("click", scoreClicked.bind(this, "fullHouse", 3), false);
document.querySelector("#score3Button12").addEventListener("click", scoreClicked.bind(this, "smStraight", 3), false);
document.querySelector("#score3Button13").addEventListener("click", scoreClicked.bind(this, "lgStraight", 3), false);
document.querySelector("#score3Button14").addEventListener("click", scoreClicked.bind(this, "yahtzee", 3), false);
document.querySelector("#score3Button15").addEventListener("click", scoreClicked.bind(this, "chance", 3), false);

//Game Over screen connection
var gameOverScreen = document.querySelector("#gameOverScreen");
var gameOver = false;
/*var restartButton = document.querySelector("#restartButton");
restartButton.addEventListener("click", resetGame, false);*/
var output = document.querySelector("#output");
var gameMessage = "";

//Variables for checking if they have rolled 3 times
//so that you don't keep rolling
var rollNum = 0;
var canRoll = true;
var turnCount = 0;

die1Freeze = document.querySelector("#die1Freeze");
die2Freeze = document.querySelector("#die2Freeze");
die3Freeze = document.querySelector("#die3Freeze");
die4Freeze = document.querySelector("#die4Freeze");
die5Freeze = document.querySelector("#die5Freeze");

var diceFreeze = [die1Freeze, die2Freeze, die3Freeze, die4Freeze, die5Freeze];

//   OBJECTS

var dieObj = {
    freeze: false,
    num: 1
}

//Object for each die
var die1 = Object.create(dieObj);
var die2 = Object.create(dieObj);
var die3 = Object.create(dieObj);
var die4 = Object.create(dieObj);
var die5 = Object.create(dieObj);

var dice = [die1, die2, die3, die4, die5];


var scoreCard = {
    1: false,
    2: false,
    3: false,
    4: false,
    5: false,
    6: false,
    
    threeKind: false,
    fourKind: false,
    fullHouse: false,
    smStraight: false,
    lgStraight: false,
    yahtzee: false,
    chance: false
}

var score2Card = {
    1: false,
    2: false,
    3: false,
    4: false,
    5: false,
    6: false,
    
    threeKind: false,
    fourKind: false,
    fullHouse: false,
    smStraight: false,
    lgStraight: false,
    yahtzee: false,
    chance: false
}

var score3Card = {
    1: false,
    2: false,
    3: false,
    4: false,
    5: false,
    6: false,
    
    threeKind: false,
    fourKind: false,
    fullHouse: false,
    smStraight: false,
    lgStraight: false,
    yahtzee: false,
    chance: false
}

//Rolling the dice
function rollDice() {
    if(gameOver === true) { mainReset(); }
    if(canRoll === true) {
        //Runs through all of the dice and randomizes their number
        for(var i = 0; i < dice.length; i++) {
            var die = dice[i];
            //checks to see if the die is frozen or if the game is over
            if(die.freeze === false && canRoll === true) {
                var ranNum = randomNum(1, 6);
                die.num = ranNum;
            }
        }
        //adds up the rolls
        rollNum++;
    }
    
    checkScore();
    
    if(rollNum === 3) {
        render();
        /*for(var j = 0; j < dice.length; j++) {
            dice[j].freeze = false;
        }
        mainReset();*/
    }
    render();
}

function freezeDie(zdieNum) {
    //  Freezes or unfreezes dice
    if(rollNum > 0 && canRoll === true) {
        var dieNum = dice[zdieNum];
        //toggle the dice freezing
        dieNum.freeze = !dieNum.freeze;
    }
    
    render();
}


function checkScore() {
    console.log("player: " + player);
    
    //console.log("CHECK SCORE CALLED");
    var diceNums = [];
    
    //figures out what numbers there are and puts them into an array
    for(var num = 0; num < dice.length; num++) {
        theDie = dice[num];
        diceNums.push(theDie.num);
    }
    
    //puts the numbers in order and displays them
    diceNums.sort();
    //console.log(diceNums);
    gameMessage = diceNums.join(" - ");
    
    var multiNums = [];
    var multiSameNums = [];
    
    var yahtzee = false;
    //Checks all the dice and sees if there are any pairs
    for(var tNum = 0; tNum < diceNums.length; tNum++) {
        var numOfSame = 0;
        var tDie = diceNums[tNum];
        //console.log("tDie " + tDie);
        
        for(var h = 0; h < diceNums.length; h++) {
            //console.log("diceNums[h] " + diceNums[h]);
            if(tDie === diceNums[h]) {
                numOfSame++;
            }
        }
        
        //checks to see if all of the numbers are the same (Yahtzee)
        if(numOfSame == 5 && multiNums.indexOf(tDie) === -1) {
            gameMessage += "<br>You have a YAHTZEE!";
            var yahtzee = true;
        }
        
        // checks to see if there are 2 or more of a number
        if(numOfSame >= 2 && multiNums.indexOf(tDie) === -1 && scoreCard[tDie] === false) {
            gameMessage += "<br>You have " + (numOfSame) + " " + tDie + "s.";
            multiNums.push(tDie);
        }
        if(scoreCard[tDie] === false && player === 1) {
            document.querySelector("#scoreDiv" + (tDie - 1)).innerHTML = tDie * numOfSame;
        } else if(score2Card[tDie] === false && player === 2) {
            document.querySelector("#score2Div" + (tDie - 1)).innerHTML = tDie * numOfSame;
        } else if(score3Card[tDie] === false && player === 3) {
            document.querySelector("#score3Div" + (tDie - 1)).innerHTML = tDie * numOfSame;
        }
        
        //puts all the dice numbers and the number of the same die
        multiSameNums.push([theDie, numOfSame]);
        numOfSame = 0;
    }
    
    if((yahtzee === true && scoreCard.yahtzee === false) && player === 1) {
        document.querySelector("#scoreDiv14").innerHTML = 50;
    } else if((yahtzee === true && score2Card.yahtzee === false) && player === 2) {
        document.querySelector("#score2Div14").innerHTML = 50;
    } else if((yahtzee === true && score3Card.yahtzee === false) && player === 3) {
        document.querySelector("#score3Div14").innerHTML = 50;
    }
    
    //checks to see if there is a double and/or a triple
    var double = false;
    var triple = false;
    var diceNumsSum = 0;
    for(var w = 0; w < diceNums.length; w++) {
        diceNumsSum += diceNums[w];
    }
    for(var sNum = 0; sNum < multiSameNums.length; sNum++) {
        if(multiSameNums[sNum][1] === 2) {
            double = true;
        } else if(multiSameNums[sNum][1] === 3) {
            triple = true;
        }
        
        if((multiSameNums[sNum][1] >= 3 && scoreCard.threeKind === false) && player === 1) {
            document.querySelector("#scoreDiv9").innerHTML = diceNumsSum;
        } else if((multiSameNums[sNum][1] >= 3 && score2Card.threeKind === false) && player === 2) {
            document.querySelector("#score2Div9").innerHTML = diceNumsSum;
        } else if((multiSameNums[sNum][1] >= 3 && score3Card.threeKind === false) && player === 3) {
            document.querySelector("#score3Div9").innerHTML = diceNumsSum;
        }
        if((multiSameNums[sNum][1] >= 4 && scoreCard.fourKind === false) && player === 1) {
            document.querySelector("#scoreDiv10").innerHTML = diceNumsSum;
        } else if((multiSameNums[sNum][1] >= 4 && score2Card.fourKind === false) && player === 2) {
            document.querySelector("#score2Div10").innerHTML = diceNumsSum;
        } else if((multiSameNums[sNum][1] >= 4 && score3Card.fourKind === false) && player === 3) {
            document.querySelector("#score3Div10").innerHTML = diceNumsSum;
        }
    }
    
    //if there is a double and a triple then it is a full house
    if((double === true && triple === true) && player === 1) {
        gameMessage += "<br>You have a full house!";
        document.querySelector("#scoreDiv11").innerHTML = 25;
    } else if((double === true && triple === true) && player === 2) {
        gameMessage += "<br>You have a full house!";
        document.querySelector("#score2Div11").innerHTML = 25;
    } else if((double === true && triple === true) && player === 3) {
        gameMessage += "<br>You have a full house!";
        document.querySelector("#score3Div11").innerHTML = 25;
    }
    
    //Checks all the dice and sees if there are any straights.
    //console.log(diceNums[0]);
    var nextNum = diceNums[0] + 1;
    var straightNums = 0;
    for(var oNum = 0; oNum < diceNums.length; oNum++) {
        if(diceNums[oNum] === (nextNum - 1)) {
            nextNum++;
            straightNums++;
        }
    }
    nextNum = diceNums[1] + 1;
    var straightNums2 = 0;
    for(var qNum = 0; qNum < diceNums.length; qNum++) {
        if(diceNums[qNum] === (nextNum - 1)) {
            nextNum++;
            straightNums2++;
        }
    }
    //console.log(straightNums);
    if(straightNums === 5 && player === 1) {
        gameMessage += "<br>You have a large straight!";
        document.querySelector("#scoreDiv13").innerHTML = 40;
    } else if(straightNums === 5 && player === 2) {
        gameMessage += "<br>You have a large straight!";
        document.querySelector("#score2Div13").innerHTML = 40;
    } else if(straightNums === 5 && player === 3) {
        gameMessage += "<br>You have a large straight!";
        document.querySelector("#score3Div13").innerHTML = 40;
    }
    if((straightNums >= 4 || straightNums2 >= 4) && player === 1) {
        gameMessage += "<br>You have a small straight!";
        document.querySelector("#scoreDiv12").innerHTML = 30;
    } else if((straightNums >= 4 || straightNums2 >= 4) && player === 2) {
        gameMessage += "<br>You have a small straight!";
        document.querySelector("#score2Div12").innerHTML = 30;
    }  else if((straightNums >= 4 || straightNums2 >= 4) && player === 3) {
        gameMessage += "<br>You have a small straight!";
        document.querySelector("#score3Div12").innerHTML = 30;
    }
    
    if(scoreCard.chance === false && player === 1) {
        var sum = 0;
        for(var p = 0; p < diceNums.length; p++) {
            sum += diceNums[p];
        }
        document.querySelector("#scoreDiv15").innerHTML = sum;
    } else if(score2Card.chance === false && player === 2) {
        var sum = 0;
        for(var p = 0; p < diceNums.length; p++) {
            sum += diceNums[p];
        }
        document.querySelector("#score2Div15").innerHTML = sum;
    } else if(score2Card.chance === false && player === 3) {
        var sum = 0;
        for(var p = 0; p < diceNums.length; p++) {
            sum += diceNums[p];
        }
        document.querySelector("#score3Div15").innerHTML = sum;
    }
    
}


function render() {
    //runs through each one of the dice
    for(var i = 0; i < dice.length; i++) {
        var die = dice[i];
        disDie = disDice[i];
        //switches the image to the random number
        disDie.src = hiddenDice[die.num - 1].src;
        if(die.freeze === true) {
            var frozenDie = diceFreeze[i];
            frozenDie.style.opacity = "1";
        } else {
            var frozenDie = diceFreeze[i];
            frozenDie.style.opacity = "0";
        }
    }
    
    if(rollNum === 3) {
        gameOverScreen.style.opacity = "1";
        canRoll = false;
        rollNum++;
        
        checkScore();
    }
    
    output.innerHTML = gameMessage;
}

function scoreClicked(zSection, zPlayerNum) {
    if(zPlayerNum === 1 && player === 1) {
        if(isNaN(zSection) === false) {
            document.querySelector("#scoreButton" + (zSection - 1)).style.visibility = "hidden";
    		document.querySelector("#scoreDiv" + (zSection - 1)).style.fontSize = "15px";
    		if(document.querySelector("#scoreDiv" + (zSection - 1)).innerHTML === "") { document.querySelector("#scoreDiv" + (zSection - 1)).innerHTML = 0; }
    		scoreCard[zSection] = true;
        } else {
            switch(zSection) {
    		    case "threeKind":
    				document.querySelector("#scoreButton9").style.visibility = "hidden";
    				document.querySelector("#scoreDiv9").style.fontSize = "15px";
    				if(document.querySelector("#scoreDiv9").innerHTML === "") { document.querySelector("#scoreDiv9").innerHTML = 0; }
    				scoreCard[zSection] = true;
    				break;
    			case "fourKind":
    				document.querySelector("#scoreButton10").style.visibility = "hidden";
    				document.querySelector("#scoreDiv10").style.fontSize = "15px";
    				if(document.querySelector("#scoreDiv10").innerHTML === "") { document.querySelector("#scoreDiv10").innerHTML = 0; }
    				scoreCard[zSection] = true;
    				break;
    			case "fullHouse":
    				document.querySelector("#scoreButton11").style.visibility = "hidden";
    				document.querySelector("#scoreDiv11").style.fontSize = "15px";
    				if(document.querySelector("#scoreDiv11").innerHTML === "") { document.querySelector("#scoreDiv11").innerHTML = 0; }
    				scoreCard[zSection] = true;
    				break;
    			case "smStraight":
    				document.querySelector("#scoreButton12").style.visibility = "hidden";
    				document.querySelector("#scoreDiv12").style.fontSize = "15px";
    				if(document.querySelector("#scoreDiv12").innerHTML === "") { document.querySelector("#scoreDiv12").innerHTML = 0; }
    				scoreCard[zSection] = true;
    				break;
    			case "lgStraight":
    				document.querySelector("#scoreButton13").style.visibility = "hidden";
    				document.querySelector("#scoreDiv13").style.fontSize = "15px";
    				if(document.querySelector("#scoreDiv13").innerHTML === "") { document.querySelector("#scoreDiv13").innerHTML = 0; }
    				scoreCard[zSection] = true;
    				break;
    			case "yahtzee":
    				document.querySelector("#scoreButton14").style.visibility = "hidden";
    				document.querySelector("#scoreDiv14").style.fontSize = "15px";
    				if(document.querySelector("#scoreDiv14").innerHTML === "") { document.querySelector("#scoreDiv14").innerHTML = 0; }
    				scoreCard[zSection] = true;
    				break;
    			case "chance":
    				document.querySelector("#scoreButton15").style.visibility = "hidden";
    				document.querySelector("#scoreDiv15").style.fontSize = "15px";
    				if(document.querySelector("#scoreDiv15").innerHTML === "") { document.querySelector("#scoreDiv15").innerHTML = 0; }
    				scoreCard[zSection] = true;
    				break;
            }
        }
    
		turnCount++;
		
		player = 2;
		
		resetGame();
    	calcFinalScore();
		
	} else if(zPlayerNum === 2 && player === 2) {
	    if(isNaN(zSection) === false) {
            document.querySelector("#score2Button" + (zSection - 1)).style.visibility = "hidden";
    		document.querySelector("#score2Div" + (zSection - 1)).style.fontSize = "15px";
    		if(document.querySelector("#score2Div" + (zSection - 1)).innerHTML === "") { document.querySelector("#score2Div" + (zSection - 1)).innerHTML = 0; }
    		score2Card[zSection] = true;
        } else {
    		switch(zSection) {
    			case "threeKind":
    				document.querySelector("#score2Button9").style.visibility = "hidden";
    				document.querySelector("#score2Div9").style.fontSize = "15px";
    				if(document.querySelector("#score2Div9").innerHTML === "") { document.querySelector("#score2Div9").innerHTML = 0; }
    				score2Card[zSection] = true;
    				break;
    			case "fourKind":
    				document.querySelector("#score2Button10").style.visibility = "hidden";
    				document.querySelector("#score2Div10").style.fontSize = "15px";
    				if(document.querySelector("#score2Div10").innerHTML === "") { document.querySelector("#score2Div10").innerHTML = 0; }
    				score2Card[zSection] = true;
    				break;
    			case "fullHouse":
    				document.querySelector("#score2Button11").style.visibility = "hidden";
    				document.querySelector("#score2Div11").style.fontSize = "15px";
    				if(document.querySelector("#score2Div11").innerHTML === "") { document.querySelector("#score2Div11").innerHTML = 0; }
    				score2Card[zSection] = true;
    				break;
    			case "smStraight":
    				document.querySelector("#score2Button12").style.visibility = "hidden";
    				document.querySelector("#score2Div12").style.fontSize = "15px";
    				if(document.querySelector("#score2Div12").innerHTML === "") { document.querySelector("#score2Div12").innerHTML = 0; }
    				score2Card[zSection] = true;
    				break;
    			case "lgStraight":
    				document.querySelector("#score2Button13").style.visibility = "hidden";
    				document.querySelector("#score2Div13").style.fontSize = "15px";
    				if(document.querySelector("#score2Div13").innerHTML === "") { document.querySelector("#score2Div13").innerHTML = 0; }
    				score2Card[zSection] = true;
    				break;
    			case "yahtzee":
    				document.querySelector("#score2Button14").style.visibility = "hidden";
    				document.querySelector("#score2Div14").style.fontSize = "15px";
    				if(document.querySelector("#score2Div14").innerHTML === "") { document.querySelector("#score2Div14").innerHTML = 0; }
    				score2Card[zSection] = true;
    				break;
    			case "chance":
    				document.querySelector("#score2Button15").style.visibility = "hidden";
    				document.querySelector("#score2Div15").style.fontSize = "15px";
    				if(document.querySelector("#score2Div15").innerHTML === "") { document.querySelector("#score2Div15").innerHTML = 0; }
    				score2Card[zSection] = true;
    				break;
            }
        }
        
    		turnCount++;
    		
    		player = 3;
    		
    		resetGame();
    	    calcFinalScore();
    		
	} else if(zPlayerNum === 3 && player === 3) {
	    if(isNaN(zSection) === false) {
            document.querySelector("#score3Button" + (zSection - 1)).style.visibility = "hidden";
    		document.querySelector("#score3Div" + (zSection - 1)).style.fontSize = "15px";
    		if(document.querySelector("#score3Div" + (zSection - 1)).innerHTML === "") { document.querySelector("#score3Div" + (zSection - 1)).innerHTML = 0; }
    		score3Card[zSection] = true;
        } else {
    		switch(zSection) {
    			case "threeKind":
    				document.querySelector("#score3Button9").style.visibility = "hidden";
    				document.querySelector("#score3Div9").style.fontSize = "15px";
    				if(document.querySelector("#score3Div9").innerHTML === "") { document.querySelector("#score3Div9").innerHTML = 0; }
    				score3Card[zSection] = true;
    				break;
    			case "fourKind":
    				document.querySelector("#score3Button10").style.visibility = "hidden";
    				document.querySelector("#score3Div10").style.fontSize = "15px";
    				if(document.querySelector("#score3Div10").innerHTML === "") { document.querySelector("#score3Div10").innerHTML = 0; }
    				score3Card[zSection] = true;
    				break;
    			case "fullHouse":
    				document.querySelector("#score3Button11").style.visibility = "hidden";
    				document.querySelector("#score3Div11").style.fontSize = "15px";
    				if(document.querySelector("#score3Div11").innerHTML === "") { document.querySelector("#score3Div11").innerHTML = 0; }
    				score3Card[zSection] = true;
    				break;
    			case "smStraight":
    				document.querySelector("#score3Button12").style.visibility = "hidden";
    				document.querySelector("#score3Div12").style.fontSize = "15px";
    				if(document.querySelector("#score3Div12").innerHTML === "") { document.querySelector("#score3Div12").innerHTML = 0; }
    				score3Card[zSection] = true;
    				break;
    			case "lgStraight":
    				document.querySelector("#score3Button13").style.visibility = "hidden";
    				document.querySelector("#score3Div13").style.fontSize = "15px";
    				if(document.querySelector("#score3Div13").innerHTML === "") { document.querySelector("#score3Div13").innerHTML = 0; }
    				score3Card[zSection] = true;
    				break;
    			case "yahtzee":
    				document.querySelector("#score3Button14").style.visibility = "hidden";
    				document.querySelector("#score3Div14").style.fontSize = "15px";
    				if(document.querySelector("#score3Div14").innerHTML === "") { document.querySelector("#score3Div14").innerHTML = 0; }
    				score3Card[zSection] = true;
    				break;
    			case "chance":
    				document.querySelector("#score3Button15").style.visibility = "hidden";
    				document.querySelector("#score3Div15").style.fontSize = "15px";
    				if(document.querySelector("#score3Div15").innerHTML === "") { document.querySelector("#score3Div15").innerHTML = 0; }
    				score3Card[zSection] = true;
    				break;
            }
        }
	
    		turnCount++;
    		
    		player = 1;
    		
    		if(turnCount >= 39) {
    			gameOver = true;
    		}
    		
    		resetGame();
    		calcFinalScore();
	}
}

function resetGame() {
    // ******* player 1's score card *******
    for(var a = 1; a < 7; a++) {
        if(scoreCard[a] === false) {
            document.querySelector("#scoreDiv" + (a - 1)).innerHTML = "";
        }
    }
    if(scoreCard.threeKind === false) {
        document.querySelector("#scoreDiv9").innerHTML = "";
    }
    if(scoreCard.fourKind === false) {
        document.querySelector("#scoreDiv10").innerHTML = "";
    }
    if(scoreCard.fullHouse === false) {
        document.querySelector("#scoreDiv11").innerHTML = "";
    }
    if(scoreCard.smStraight === false) {
        document.querySelector("#scoreDiv12").innerHTML = "";
    }
    if(scoreCard.lgStraight === false) {
        document.querySelector("#scoreDiv13").innerHTML = "";
    }
    if(scoreCard.yahtzee === false) {
        document.querySelector("#scoreDiv14").innerHTML = "";
    }
    if(scoreCard.chance === false) {
        document.querySelector("#scoreDiv15").innerHTML = "";
    }
    
    // ******* player 2's score card *******
    for(var q = 1; q < 7; q++) {
        if(score2Card[q] === false) {
            document.querySelector("#score2Div" + (q - 1)).innerHTML = "";
        }
    }
    if(score2Card.threeKind === false) {
        document.querySelector("#score2Div9").innerHTML = "";
    }
    if(score2Card.fourKind === false) {
        document.querySelector("#score2Div10").innerHTML = "";
    }
    if(score2Card.fullHouse === false) {
        document.querySelector("#score2Div11").innerHTML = "";
    }
    if(score2Card.smStraight === false) {
        document.querySelector("#score2Div12").innerHTML = "";
    }
    if(score2Card.lgStraight === false) {
        document.querySelector("#score2Div13").innerHTML = "";
    }
    if(score2Card.yahtzee === false) {
        document.querySelector("#score2Div14").innerHTML = "";
    }
    if(score2Card.chance === false) {
        document.querySelector("#score2Div15").innerHTML = "";
    }
    
    // ******* player 3's score card *******
    for(var p = 1; p < 7; p++) {
        if(score3Card[p] === false) {
            document.querySelector("#score3Div" + (p - 1)).innerHTML = "";
        }
    }
    if(score3Card.threeKind === false) {
        document.querySelector("#score3Div9").innerHTML = "";
    }
    if(score3Card.fourKind === false) {
        document.querySelector("#score3Div10").innerHTML = "";
    }
    if(score3Card.fullHouse === false) {
        document.querySelector("#score3Div11").innerHTML = "";
    }
    if(score3Card.smStraight === false) {
        document.querySelector("#score3Div12").innerHTML = "";
    }
    if(score3Card.lgStraight === false) {
        document.querySelector("#score3Div13").innerHTML = "";
    }
    if(score3Card.yahtzee === false) {
        document.querySelector("#score3Div14").innerHTML = "";
    }
    if(score3Card.chance === false) {
        document.querySelector("#score3Div15").innerHTML = "";
    }
    
    gameOverScreen.style.opacity = "0";
    for(var i = 0; i < dice.length; i++) {
        die = dice[i];
        die.freeze = false;
        die.num = 1;
    }
    
    canRoll = true;
    rollNum = 0;
    
    gameMessage = "";
    
    render();
}

function mainReset() {
    for(var i = 0; i <= 18; i++) {
        if(i != 6 && i != 7 && i != 8 && i != 16 && i != 17 && i != 18) {
            document.querySelector("#scoreDiv" + i).innerHTML = "";
            document.querySelector("#score2Div" + i).innerHTML = "";
            document.querySelector("#score3Div" + i).innerHTML = "";
            document.querySelector("#scoreButton" + i).style.visibility = "visible";
            document.querySelector("#score2Button" + i).style.visibility = "visible";
            document.querySelector("#score3Button" + i).style.visibility = "visible";
    		document.querySelector("#scoreDiv" + i).style.fontSize = "8px";
    		document.querySelector("#score2Div" + i).style.fontSize = "8px";
    		document.querySelector("#score3Div" + i).style.fontSize = "8px";
        } else if(i === 6 || i === 7 || i === 8 || i === 17 || i === 18) {
            document.querySelector("#scoreDiv" + i).innerHTML = "";
            document.querySelector("#score2Div" + i).innerHTML = "";
            document.querySelector("#score3Div" + i).innerHTML = "";
        }
    }
    for(var j = 1; j <= 6; j++) {
    	scoreCard[j] = false;
    	score2Card[j] = false;
    	score3Card[j] = false;
    }
    
    scoreCard.threeKind = false;
    scoreCard.fourKind = false;
    scoreCard.fullHouse = false;
    scoreCard.smStraight = false;
    scoreCard.lgStraight = false;
    scoreCard.yahtzee = false;
    scoreCard.chance = false;
    
    score2Card.threeKind = false;
    score2Card.fourKind = false;
    score2Card.fullHouse = false;
    score2Card.smStraight = false;
    score2Card.lgStraight = false;
    score2Card.yahtzee = false;
    score2Card.chance = false;
    
    score3Card.threeKind = false;
    score3Card.fourKind = false;
    score3Card.fullHouse = false;
    score3Card.smStraight = false;
    score3Card.lgStraight = false;
    score3Card.yahtzee = false;
    score3Card.chance = false;
    
    player = 1;
    turnCount = 0;
    rollNum = 0;
    gameOver = false;
}

function calcFinalScore() {
    // ********** Player 1's score ********
    // first half of the Score card
    var upperSum = 0;
    for(var i = 0; i <= 5; i++) {
        if(document.querySelector("#scoreDiv" + i).innerHTML != "") {
            upperSum += Number(document.querySelector("#scoreDiv" + i).innerHTML);
        }
    }
    document.querySelector("#scoreDiv6").innerHTML = upperSum;
    
    var bonus1 = 0;
    if(upperSum >= 63) {
        document.querySelector("#scoreDiv7").innerHTML = 35;
        bonus1 = 35;
    } else {
        document.querySelector("#scoreDiv7").innerHTML = 0;
    }
    
    document.querySelector("#scoreDiv8").innerHTML = upperSum + bonus1;
    
    // second half of the Score card
    var lowerSum = 0;
    for(var j = 9; j <= 15; j++) {
        if(document.querySelector("#scoreDiv" + j).innerHTML != "") {
            lowerSum += Number(document.querySelector("#scoreDiv" + j).innerHTML);
        }
    }
    document.querySelector("#scoreDiv17").innerHTML = lowerSum;
    
    document.querySelector("#scoreDiv18").innerHTML = upperSum + lowerSum + bonus1;
    
    // ********** Player 2's score ********
    //first half of the score card
    var upper2Sum = 0;
    for(var e = 0; e <= 5; e++) {
        if(document.querySelector("#score2Div" + e).innerHTML != "") {
            upper2Sum += Number(document.querySelector("#score2Div" + e).innerHTML);
        }
    }
    document.querySelector("#score2Div6").innerHTML = upper2Sum;
    
    var bonus2 = 0;
    if(upper2Sum >= 63) {
        document.querySelector("#score2Div7").innerHTML = 35;
        bonus2 = 35;
    } else {
        document.querySelector("#score2Div7").innerHTML = 0;
    }
    
    document.querySelector("#score2Div8").innerHTML = upper2Sum + bonus2;
    
    //second half of the score card
    var lower2Sum = 0;
    for(var f = 9; f <= 15; f++) {
        if(document.querySelector("#score2Div" + f).innerHTML != "") {
            lower2Sum += Number(document.querySelector("#score2Div" + f).innerHTML);
        }
    }
    document.querySelector("#score2Div17").innerHTML = lower2Sum;
    
    document.querySelector("#score2Div18").innerHTML = upper2Sum + lower2Sum + bonus2;
    
    // ********** Player 3's score ********
    //first half of the score card
    var upper3Sum = 0;
    for(var e = 0; e <= 5; e++) {
        if(document.querySelector("#score3Div" + e).innerHTML != "") {
            upper3Sum += Number(document.querySelector("#score3Div" + e).innerHTML);
        }
    }
    document.querySelector("#score3Div6").innerHTML = upper3Sum;
    
    var bonus3 = 0;
    if(upper3Sum >= 63) {
        document.querySelector("#score3Div7").innerHTML = 35;
        bonus3 = 35;
    } else {
        document.querySelector("#score3Div7").innerHTML = 0;
    }
    
    document.querySelector("#score3Div8").innerHTML = upper3Sum + bonus3;
    
    //second half of the score card
    var lower3Sum = 0;
    for(var f = 9; f <= 15; f++) {
        if(document.querySelector("#score3Div" + f).innerHTML != "") {
            lower3Sum += Number(document.querySelector("#score3Div" + f).innerHTML);
        }
    }
    document.querySelector("#score3Div17").innerHTML = lower3Sum;
    
    document.querySelector("#score3Div18").innerHTML = upper3Sum + lower3Sum + bonus3;
}

function randomNum(Min, Max) {
    return Math.floor(Math.random() * (Max - Min + 1) + Min);
}