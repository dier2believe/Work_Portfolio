/*
 * File:    HW02_LizDieringer.c
 * Project: Homework 3
 * Propose: Implement a BST and traversals
 * Author:  Elizabeth (Liz) Dieringer
 * Version: 1.0 November 1, 2019
 *
 * Copyright 2019 (c) Elizabeth Dieringer All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>

/* Structures */
typedef struct Tree_Node {
    char key;
    char data[10];
    struct Tree_Node *left;
    struct Tree_Node *right;
} TREE_NODE;

typedef struct Stack_Node {
    struct Tree_Node *treeNode;
    struct Stack_Node *down;
} STACK_NODE;

/* Function declarations */
void insert(TREE_NODE *newItem, TREE_NODE **root);
void find(char c, TREE_NODE *root);
void preOrder(TREE_NODE *q);
void inOrder(TREE_NODE *q);
void push(TREE_NODE *root, STACK_NODE **top);
TREE_NODE *pop(STACK_NODE **top);
int isEmpty(STACK_NODE *top);

/* Main */
int main() {
    // Set up the user input variable 
    char c = 'c';
    // Set up the pointer to the root of the binary tree and the newitem
    TREE_NODE *root = NULL, *newItem;
    
    // Run the program until the user insert a q to quit
    while ((c != 'q') && (c != 'Q')) {
        // Ask the user what they would like to do
        printf("\nEnter a choice (lower case is also acceptable) --- (I)nsert, (F)ind, (Q)uit: ");
        scanf(" %c", &c);
        
        // Determine what to do based on the user input
        switch (c) {
            case 'i':
            case 'I':
                // If they want to insert get new memory for the tree node
                newItem = malloc(sizeof(TREE_NODE));
                // Ask the values for the tree node data
                printf("\nEnter new node's key value: ");
                scanf(" %c", &newItem->key);
                printf("\nEnter string of up to 10 characters for '%c's data: ",
                       newItem->key);
                scanf(" %s", &newItem->data);
                // Insert the newItem into the tree
                insert(newItem, &root);
                
                // Print the Pre-Order Traversal
                printf("\n  Pre-order traversal is: ");
                preOrder(root);
                printf("\n");
                
                // Print the In-Order Traversal
                printf("  In-order traversal is: ");
                inOrder(root);
                printf("\n");
                
                // In case the newItem was a q reset the input to original
                c = 'i';
                break;
            case 'f':
            case 'F':
                // Ask the user what it wants to search for
                printf("\nEnter the search key: ");
                scanf(" %c", &c);
                // Find and print it
                find(c, root);
                
                // In case the newItem was a q reset the input to original
                c = 'f';
                break;
        }
    }
    
    
    
    return 0;
}

/* Functions */

// Insert Function for Binary Tree
void insert(TREE_NODE *newItem, TREE_NODE **root) {
    // Set up the traversal pointer (q)
    TREE_NODE *q = NULL;
    int done = 0;
    // Make sure that the tree is not null
    if ((*root) == NULL) {
        // if it is null the newItem is the root
        (*root) = newItem;
    } else {
        // if it is not null set the traversal pointer to root
        q = (*root);
        while (!done) {
            // if the new letter is less than the current tree node
            if (newItem->key < q->key) {
                // check to see if the current tree node has a left child
                if (q->left == NULL) {
                    // if it doesn't set it to the newItem
                    q->left = newItem;
                    done++;
                } else {
                    // if it does move there and keep looking
                    q = q->left;
                }
            // if the new letter is more than the current tree node
            } else if (newItem->key > q->key) {
                // check to see if the current tree node has a right child
                if (q->right == NULL) {
                    // if it doesn't set it to the newItem
                    q->right = newItem;
                    done++;
                } else {
                    // if it does move there and keep looking
                    q = q->right;
                }
            } else {
                printf("That node already exists.\n");
            }
        }
    }
}

// Find Function for Binary Tree
void find(char c, TREE_NODE *root) {
    // Set up the traversal pointer (q) equal to root
    TREE_NODE *q = root;
    // While still on the tree and it hasn't been found
    while ((q != NULL) && (q->key != c)) {
        // if the character is less than the current node character move left
        if (c < q->key) {
            q = q->left;
        // if the character is more than the current node character move right
        } else if (c > q->key) {
            q = q->right;
        }
    }
    if (q == NULL) {
        // notify the user the search failed
        printf("\n  '%c' is not in the tree\n", c);
    } else {
        // show the data found in the node
        printf("\n  Found the string \"%s\" there.\n", q->data);
    }
}

// Nonrecursive Pre-Order Traversal of Binary Tree
void preOrder(TREE_NODE *q) {
    // create the local pointer to the top of a stack
    STACK_NODE *top = NULL;
    int done = 0;
    while (!done) {
        // While pointer is still on the tree
        while (q != NULL) {
            // print the root
            printf("%c ", q->key);
            // Move to the left if there is a left node
            if (q->left != NULL) {
                push(q, &top);
                q = q->left;
            // otherwise move right
            } else {
                q = q->right;
            }
        }
        // if the stack is empty then end the traversal
        if (isEmpty(top)) {
            done++;
        // otherwise pop the top of the stack and continue from there
        } else {
            q = pop(&top);
            // move to the right of the poped binary tree node
            q = q->right;
        }
    }
}

// Nonrecursive In-Order Traversal of Binary Tree
void inOrder(TREE_NODE *q) {
    // create the local pointer to the top of a stack
    STACK_NODE *top = NULL;
    int done = 0;
    while (!done) {
        // While pointer is still on the tree
        while (q != NULL) {
            // Move to the left if there is a left node
            if (q->left != NULL) {
                push(q, &top);
                q = q->left;
            // otherwise print the root and then move to the right
            } else {
                printf("%c ", q->key);
                q = q->right;
            }
        }
        // if the stack is empty then end the traversal
        if (isEmpty(top)) {
            done++;
        // otherwise pop the top of the stack and continue from there
        } else {
            q = pop(&top);
            // print the root then move to the right
            printf("%c ", q->key);
            q = q->right;
        }
    }
}


/* Stack Functions */

// Push Function for Stack
void push(TREE_NODE *tNode, STACK_NODE **top) {
    // Sets up the temporary newItem for the stack
    STACK_NODE *newItem;
    newItem = malloc(sizeof(STACK_NODE));
    newItem->treeNode = tNode;
    // If the stack is empty it makes the stack
    if (*top == NULL) {
        *top = newItem;
    // otherwise add it to the top of the existing stack
    } else {
        newItem->down = *top;
        *top = newItem;
    }
}

// Pop Function for Stack
TREE_NODE *pop(STACK_NODE **top) {
    // Sets up the item to delete and the item to return
    STACK_NODE *delItem = NULL;
    TREE_NODE *returnItem = NULL;
    // Makes sure that the stack is not empty
    if (*top != NULL) {
        // Sets up the delItem to be the top of the stack
        delItem = *top;
        // Sets up the pointer to be returned.
        returnItem = (*top)->treeNode;
        // Moves the top of the stack
        *top = (*top)->down;
        // Frees up the memory of the deleted item
        free(delItem);
        // returns the pointer to the tree node
        return returnItem;
    } else {
        // if there is nothing to remove, it notifies the user and exits
        printf("The stack is empty\n");
        return NULL;
    }
}

// isEmpty Function for Stack
int isEmpty(STACK_NODE *top) {
    // checks to see if the stack pointer is NULL / empty
    if (top == NULL) {
        return 1;
    } else {
        return 0;
    }
}





