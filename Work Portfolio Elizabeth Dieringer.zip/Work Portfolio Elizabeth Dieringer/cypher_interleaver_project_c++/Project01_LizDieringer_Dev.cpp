/* Name: Liz Diringer
 * Class: CS303
 * Assignmeant: Project 1
 * Purpose: To encrypt using an interleaver
 */

// Includes
#include <iostream>
#include <string>
#include <cstring>
#include <fstream>
using namespace std;

// Function Statements
string getPlaintext();
string fixPlaintext(string plaintext);
int getColNum();
char *createIntBox(string plaintext, int colNum);
char *encrypt(char *intBox, int colNum);
void writeCiphertext(char *ciphertext);

// Functions
int main() {
    string plaintext = getPlaintext();
    string fixedPlaintext = fixPlaintext(plaintext);
    int colNum = getColNum();
    char *intBox = createIntBox(fixedPlaintext, colNum);
    char *ciphertext = encrypt(intBox, colNum);
    writeCiphertext(ciphertext);
    return 0;
}

string getPlaintext() {
    string plaintext;

    cout << "Make sure you have your plaintext in the plaintext.txt file" << endl;
    ifstream fin ("plaintext.txt");
    if (fin.fail()) {
        cout << "There is no plaintext.txt file" << endl;
    } else {
        getline(fin, plaintext);
        fin.close();
    }
    //cout << "Text from file: " << plaintext << endl;
    
    return plaintext;
}

string fixPlaintext(string plaintext) {
    string fixedPlaintext;
    int i = 0;

    plaintext += '\n';
    while (plaintext[i] != '\n') {
        if ((plaintext[i] >= 65) && (plaintext[i] <= 90)) {
            fixedPlaintext += plaintext[i];
        } else if ((plaintext[i] >= 97) && (plaintext[i] <= 122)) {
            fixedPlaintext += (plaintext[i] - 32);
        }
        i++;
    }

    //cout << "Text after being fixed: " << fixedPlaintext << endl;

    return fixedPlaintext;
}

int getColNum() {
    int colNum;
    cout << "How many columns do you want for the interleaver? ";
    cin >> colNum;
    return colNum;
}

char *createIntBox(string plaintext, int colNum) {
    int size = plaintext.size();
    //cout << endl << "plaintext size: " << plaintext.size() << endl;
    //cout << "plaintext % colNum: " << (plaintext.size() % colNum) << endl;
    //cout << "intBox size: " << size << endl;
    char *intBox;

    if ((plaintext.size() % colNum) != 0) {
        size += (colNum - (plaintext.size() % colNum));
    }
    intBox = new char[size];
    
    for (int i = 0; i < size; i++) {
        if (i < plaintext.size()) {
            intBox[i] = plaintext[i];
        } else {
            intBox[i] = 'Z';
        }
    }
    //cout << "Intbox: " << intBox << endl << endl;
    return intBox;
}

char *encrypt(char *intBox, int colNum) {
    char *ciphertext;
    int nextLetter;
    int nextPlace = 0;
    int j;
    ciphertext = new char[strlen(intBox)];
    //cout << "CipherText1: ";
    for (int i = 0; i < colNum; i++) {
        j = 0;
        nextLetter = j * colNum + i;
        while (nextLetter < strlen(intBox)) {
            //cout << intBox[nextLetter];
            ciphertext[nextPlace] = intBox[nextLetter];
            nextPlace++;
            j++;
            nextLetter = j * colNum + i;
        }
    }
    //cout << endl << "Ciphertext: " << ciphertext << endl;
    return ciphertext;
}

void writeCiphertext(char *ciphertext) {
    ofstream fout("ciphertext.txt");
    if (fout.fail()) {
        cout << "There is no ciphertext.txt file" << endl;
    } else {
        fout << ciphertext;
        fout.close();
    }
}

