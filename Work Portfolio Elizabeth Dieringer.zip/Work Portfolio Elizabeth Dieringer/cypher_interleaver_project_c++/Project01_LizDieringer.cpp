/*
 * File:    Projet01_LizDieringer.c
 * Project: Project01
 * Propose: To encrypt using an interleaver
 * Author:  Elizabeth (Liz) Dieringer
 * Version: 1.0 February 8, 2019
 *
 * Copyright 2019 (c) Elizabeth Dieringer All rights reserved.
 */

// Includes
#include <iostream>
#include <string>
#include <cstring>
#include <fstream>
using namespace std;

// Function Statements
string getPlaintext();
string fixPlaintext(string plaintext);
int getColNum();
char *createIntBox(string plaintext, int colNum);
char *encrypt(char *intBox, int colNum);
void writeCiphertext(char *ciphertext);

// Functions
int main() {
    string plaintext;
    string fixedPlaintext;
    int colNum;
    char *intBox;
    char *ciphertext;
    
    try {
        plaintext = getPlaintext();
        fixedPlaintext = fixPlaintext(plaintext);
        colNum = getColNum();
        intBox = createIntBox(fixedPlaintext, colNum);
        ciphertext = encrypt(intBox, colNum);
        writeCiphertext(ciphertext);
    }
    catch (int x) {
        cout << "No plaintext found, so program has ended." << endl;
    }

    return 0;
}

// This function gets the plaintext from a file
string getPlaintext() {
    string plaintext = "File not found";

    // Let's the user know what the file name is that it is taking from
    cout << "Make sure you have your plaintext in the plaintext.txt file" << endl;
    // Trys to open the file
    ifstream fin ("plaintext.txt");
    // If the file didn't open then it throws an exception
    if (fin.fail()) {
        throw(0);
    // If it does open then it reads from the file
    } else {
        getline(fin, plaintext);
        fin.close();
    }
    
    // It returns what it got from the file
    return plaintext;
}

// Takes plaintext and gets it ready to be encrypted
string fixPlaintext(string plaintext) {
    string fixedPlaintext;
    int i = 0;

    plaintext += '\n';
    // While not at the end of the plaintext
    while (plaintext[i] != '\n') {
        // Check if it's an uppercase character
        if ((plaintext[i] >= 65) && (plaintext[i] <= 90)) {
            // If so add it to the new plaintext
            fixedPlaintext += plaintext[i];
        // Check if it's a lowercase character
        } else if ((plaintext[i] >= 97) && (plaintext[i] <= 122)) {
            // If so capatalize it and add it to the new plaintext
            fixedPlaintext += (plaintext[i] - 32);
        }
        i++;
    }

    // Returns new plaintext without spaces or punctuation
    return fixedPlaintext;
}

// Asks for how many columns the user wants
int getColNum() {
    int colNum;
    cout << "How many columns do you want for the interleaver? ";
    cin >> colNum;
    return colNum;
}

// Creates the table for encryption
char *createIntBox(string plaintext, int colNum) {
    int size = plaintext.size();
    char *intBox;

    // Checks if the table is full
    if ((plaintext.size() % colNum) != 0) {
        // If not then add the extra spaces to the size
        size += (colNum - (plaintext.size() % colNum));
    }
    // Create the table with the full size
    intBox = new char[size];
    
    // Puts all of the plaintext into the table
    for (int i = 0; i < size; i++) {
        if (i < plaintext.size()) {
            intBox[i] = plaintext[i];
        } else {
            // It then adds Zs to the rest of the empty space
            intBox[i] = 'Z';
        }
    }
    
    // Returns the table
    return intBox;
}

// Ecrypts the plaintext using a previously created table
char *encrypt(char *intBox, int colNum) {
    char *ciphertext;
    int nextLetter;
    int nextPlace = 0;
    int j;
    ciphertext = new char[strlen(intBox)];
    
    // It runs through the table column wise
    for (int i = 0; i < colNum; i++) {
        j = 0;
        nextLetter = j * colNum + i;
        while (nextLetter < strlen(intBox)) {
            // It adds the next letter to the ciphertext
            ciphertext[nextPlace] = intBox[nextLetter];
            nextPlace++;
            j++;
            nextLetter = j * colNum + i;
        }
    }
    
    // Returns the encrypted ciphertext
    return ciphertext;
}

// Takes text and writes it to a file
void writeCiphertext(char *ciphertext) {
    // opens the file
    ofstream fout("ciphertext.txt");
    if (fout.fail()) {
        cout << "There is no ciphertext.txt file" << endl;
    } else {
        // If it doesn't fail then it writes the text to the file
        fout << ciphertext;
        fout << endl;
        // The file is closed
        fout.close();
    }
}

